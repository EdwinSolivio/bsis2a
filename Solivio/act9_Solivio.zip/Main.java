public class Main {
    public static void main(String[] args){
        String str = "Hello";
        boolean flag = str.endsWith("lo");
        System.out.println(flag);
    }
}
