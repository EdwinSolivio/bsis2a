public class act9_no2 {
    public static void main(String[] args){
        int digit = 15;
        int radix = 16;
        char letter = Character.forDigit(digit, radix);
        System.out.println(Character.forDigit(digit,radix));
    }
}
