public class act9_no3 {
    public static void main(String[] args){
        System.exit(0);
    }
}
