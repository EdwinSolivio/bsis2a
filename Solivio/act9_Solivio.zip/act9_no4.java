public class act9_no4 {
    public static void main (String[] args){
        double x = 3.13;
        double floored = Math.floor(x);
        System.out.println(floored);

    }
}
