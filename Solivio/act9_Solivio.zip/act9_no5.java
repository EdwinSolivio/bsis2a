public class act9_no5 {
    public static void main(String[] args){
        boolean flag = Character.isDigit('3');
        System.out.println(flag);
    }
}
